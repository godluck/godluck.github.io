$(document).ready(function() {
    function onResize() {
        var rem = fui.flexible.rem;
        $('.flexible-box').width(rem * 15).height(rem * 10).css('margin', -1 * rem * 5 + 'px 0 0 ' + (-1) * rem * 7.5 +
            'px');
        $('.flexible-bottom').width(rem * 15).height(rem * 10).css('margin', '0 0 0 ' + (-1) * rem * 7.5 + 'px');
    }

    function onLeave(index, nextIndex, direction) {
        var isOnFooter = index === 5 && nextIndex === 6 || index === 6 && index === 5;
        if(!isOnFooter){
            $('.section-' + nextIndex).css('opacity', 1).addClass('animated');
            previousTarget = $('.section-' + index);
        }
    }

    var previousTarget = $('.section-1');
    $('#slider-wrapper').fullpage({
        resize: true,
        css3: true,
        afterRender: function() {
            onResize();
            $('.section').css('opacity', 0);
            $('.section-1').css('opacity', 1).addClass('animated');
        },
        afterLoad: function() {
            previousTarget.css('opacity', 0).removeClass('animated');
        },
        afterResize: onResize,
        onLeave: onLeave
    });
})