/**
 * Created by qingrun.cqr on 2015/8/20.
 */
function resize(ele, config) {
    normalizeConfig(config);
    var eleRect = ele.getBoundingClientRect();
    var eleWidth = eleRect.right - eleRect.left;
    var eleHeight = eleRect.bottom - eleRect.top;

    var eleParent = ele.parentNode();
    var eleParentRect = eleParent.getBoundingClientRect();
    var eleParentWidth = eleParentRect.right - eleParentRect.left;
    var eleParentHeight = eleParentRect.bottom - eleParentRect.top;

    var eleRatio, eleParentRatio;

    var eleType = config.type;

    if (eleParentHeight > 0 && eleParentWidth > 0) {
        eleParentRatio = eleParentWidth / eleParentHeight;
    } else {
        return;
    }

    if (eleHeight > 0 && eleWidth > 0) {
        eleRatio = eleWidth / eleHeight;
    }

    eleRatio = config.ratio || eleRatio;

    if (eleRatio) {
        if (eleType === 'contain') {
            sizerContain();
        } else if (eleType === 'cover') {
            sizerCover();
        }
    } else {
        ele.style.width = eleParentWidth + 'px';
        ele.style.height = eleParentHeight + 'px';
    }

    function sizerContain() {
        if (eleRatio > eleParentRatio) {
            //widder content
            ele.style.width = eleParentWidth + 'px';
            ele.style.height = eleParentWidth / eleRatio + 'px';
        } else {
            //higher content
            ele.style.height = eleParentHeight + 'px';
            ele.style.width = eleParentHeight * eleRatio + 'px';
        }
    }

    function sizerCover() {
        var horizontalTotalPadding, horizontalSpace, paddingAdded, paddingLeft,
            verticalTotalPadding, verticalSpace, paddingTop,
            isExceeded = false, w, h;
        if (eleRatio > eleParentRatio) {
            //wider content
            horizontalTotalPadding = config.padding[1] + config.padding[3];
            if (horizontalTotalPadding > 0) {
                //none zero horizontal padding
                horizontalSpace = 1 - 1 / (eleRatio / eleParentRatio);
                if (horizontalSpace > horizontalTotalPadding) {
                    //when maximum padding is exceeded, take it as the weighted padding, the rest padding is
                    //separated as 1:1
                    isExceeded = true;
                    paddingAdded = config.padding[3];
                } else {
                    //weighted padding
                    paddingAdded = config.padding[3] / horizontalTotalPadding * horizontalSpace;
                }
                //the position of the center line
                paddingLeft = (1 - horizontalSpace) / 2 + paddingAdded;
            } else {
                //no padding set, take the center of the element as the center line
                paddingLeft = 0.5;
            }
            if (isExceeded && config.strict) {
                w = 1 / (1 - horizontalSpace) * eleParentWidth;
                h = eleParentWidth / (1 - horizontalSpace) / eleRatio;
                ele.style.width = w + 'px';
                ele.style.height = h + 'px';
                ele.style.marginTop = -1 * h / 2 + 'px';
                ele.style.marginLeft = -1 * paddingLeft * w + 'px';
            } else {
                ele.style.height = '100%';
                ele.style.width = eleParentHeight * eleRatio + 'px';
                ele.style.marginLeft = -1 * paddingLeft * eleParentHeight * eleRatio + 'px';
            }
        } else {
            //higher content
            verticalTotalPadding = config.padding[0] + config.padding[2];
            if (verticalTotalPadding > 0) {
                //none zero vertical padding
                verticalSpace = 1 - 1 / (eleParentRatio / eleRatio);
                if (verticalSpace > verticalTotalPadding) {
                    //when maximum padding is exceeded, take it as the weighted padding, the rest padding is
                    //separated as 1:1
                    isExceeded = true;
                    paddingAdded = config.padding[0];
                } else {
                    //weighted padding
                    paddingAdded = config.padding[0] / verticalTotalPadding * verticalSpace;
                }
                //the position of the center line
                paddingTop = (1 - verticalSpace) / 2 + paddingAdded;
            } else {
                //no padding set, take the center of the element as the center line
                paddingTop = 0.5;
            }
            if (isExceeded && config.strict) {
                h = 1 / (1 - verticalSpace) * eleParentHeight;
                w = eleParentHeight / (1 - verticalSpace) * eleRatio;
                ele.style.width = w + 'px';
                ele.style.height = h + 'px';
                ele.style.marginTop = -1 * paddingTop * h + 'px';
                ele.style.marginLeft = -1 * w / 2 + 'px';
            } else {
                ele.style.width = '100%';
                ele.style.height = eleParentWidth / eleRatio + 'px';
                ele.style.marginTop = -1 * paddingTop * eleParentWidth / eleRatio + 'px';
            }
        }
    }
}

function normalizeConfig(config) {
    config.type = config.type.toLowerCase() === 'contain' ? 'contain' :
        config.type.toLowerCase() === 'cover' ? 'cover' : 'contain';
    config.ratio = +config.ratio > 0 ? +config.ratio : 0;
    if (Object.prototype.toString.call(config.padding) === '[object Array]') {
        for (var i = 0, l = config.padding.length; i < l; i++) {
            if (config.padding[i] < 0 || config.padding[i] >= 1) {
                console.error('invalid padding ratio number!');
                config.padding[i] = 0;
            }
        }
        switch (l) {
            case 1:
                if (config.padding[0] < 0.5) {
                    config.padding = [
                        config.padding[0],
                        config.padding[0],
                        config.padding[0],
                        config.padding[0]
                    ];
                } else {
                    config.padding = [0, 0, 0, 0];
                }
                break;
            case 2:
                if (config.padding[0] < 0.5 && config.padding[1] < 0.5) {
                    config.padding = [
                        config.padding[0],
                        config.padding[1],
                        config.padding[0],
                        config.padding[1]
                    ];
                } else {
                    config.padding = [0, 0, 0, 0];
                }
                break;
            case 3:
                if (config.padding[0] + config.padding[2] <= 1 && config.padding[1] < 0.5) {
                    config.padding = [
                        config.padding[0],
                        config.padding[1],
                        config.padding[2],
                        config.padding[1]
                    ];
                } else {
                    config.padding = [0, 0, 0, 0];
                }
                break;
            case 4:
                if (!(config.padding[0] + config.padding[2] <= 1 && config.padding[1] + config.padding[3] <= 1)) {
                    config.padding = [0, 0, 0, 0];
                }
                break;
            default:
                config.padding = [0, 0, 0, 0];
        }
    } else {
        config.padding = [0, 0, 0, 0];
    }
    config.strict = config.strict ? config.strict.toString().toLowerCase() === 'true' : false;
}